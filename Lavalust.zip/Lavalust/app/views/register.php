<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            overflow: hidden;
        }

        form {
            background: rgba(255, 255, 255, 0.8); 
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px); 
            width: 100%;
            max-width: 350px;
            animation: fadeIn 1.5s ease-in-out; 
        }

        h2 {
            text-align: center;
            margin-bottom: 2rem;
            font-weight: bold;
            color: #333;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 1rem;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: inset 0 1px 5px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        input:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 1);
            box-shadow: 0 0 5px rgba(255, 99, 132, 0.5);
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #f093fb;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #f5576c;
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        button:active {
            transform: translateY(0);
        }

        .footer {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 1rem;
            text-align: center;
            font-size: 14px;
            color: #555;
        }

        a {
            color: #f093fb;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #f5576c;
            text-decoration: underline;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 480px) {
            form {
                padding: 1.5rem;
            }

            input, button {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <form method="POST" action="register/submit">
        <h2>Register</h2>
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Register</button>
        <div class="footer">
            <p>Already have an account? <a href="/login">Login here</a></p>
            <a href="/email">Send Email Here</a>
        </div>
    </form>
</body>
</html>
