<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Email</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: radial-gradient(circle, #ffafbd, #ffc3a0);
            overflow: hidden;
        }

        form {
            background: rgba(255, 255, 255, 0.85); 
            padding: 2.5rem;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(12px); 
            width: 100%;
            max-width: 400px;
            animation: fadeInUp 1s ease-out; 
        }

        h2 {
            text-align: center;
            margin-bottom: 2rem;
            font-size: 1.8rem;
            font-weight: bold;
            color: #333;
        }

        input, textarea {
            width: 100%;
            padding: 14px;
            margin-bottom: 1.2rem;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            background-color: rgba(255, 255, 255, 0.9);
            box-shadow: inset 0 1px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus {
            outline: none;
            background-color: rgba(255, 255, 255, 1);
            box-shadow: 0 0 8px rgba(255, 136, 0, 0.4);
        }

        textarea {
            height: 150px;
            resize: none;
        }

        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            background-color: #ffafbd;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.4s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #ffc3a0;
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        button:active {
            transform: translateY(0);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        button::after {
            content: '';
            display: block;
            position: absolute;
            width: 0;
            height: 100%;
            top: 0;
            left: 0;
            background: rgba(255, 255, 255, 0.2);
            transition: width 0.4s ease;
            border-radius: 8px;
        }

        button:hover::after {
            width: 100%;
        }

        /* New styles for the links section */
        .links {
            margin-top: 1.5rem;
            text-align: center;
            font-size: 14px;
            color: #555;
        }

        .links a {
            color: #ffafbd;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
            margin: 0 5px;
        }

        .links a:hover {
            color: #ffc3a0;
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            form {
                padding: 1.8rem;
            }

            input, textarea, button {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
    <form method="POST" action="email" enctype="multipart/form-data">
        <h2>Send Email</h2>
        <input type="email" name="email" placeholder="Recipient Email" required />
        <input type="text" name="subject" placeholder="Subject" required />
        <textarea name="message" placeholder="Message" required></textarea>
        <input type="text" name="sender" placeholder="Sender" required />
        <input type="file" name="name" required />
        <button type="submit">Send Email</button>
        <div class="links">
            <p><a href="/register">Register Page</a> | <a href="/login">Login Page</a></p>
        </div>
    </form>
</body>
</html>
